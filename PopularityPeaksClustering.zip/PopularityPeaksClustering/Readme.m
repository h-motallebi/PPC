% Matlab source code for "Popularity Peaks Clustering (PPC) algorithm"
% Please cite [Hassan Motallebi and Najmeh Malakoutifar‎: An efficient clustering algorithm based on searching popularity peaks, Pattern Analysis and Applications, 2024]

% Please run "main.m" file