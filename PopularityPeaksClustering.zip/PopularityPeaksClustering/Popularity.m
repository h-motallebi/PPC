classdef (ConstructOnLoad) Popularity
    properties (Constant)
        DefaultMarkOutliers = false;
        DefaultWeightVectorComputationMethod = 'GeometricWithMinValue';
        DefaultWeightVectorComputationParameter = -1;
        DefaultMaximumNumberOfIterations = -1;
        DefaultUpperBoundForNumberOfIterations = 100;        
        DefaultNSSDThresholdForNumberOfIterations = 0.001;
        DefaultMaxK = 100;
        DefaultNSSDThresholdForK = 0.001;
        DefaultKnFactor = 5;
        DefaultK = 0;
        DefaultSelfLoop = false;
    end
    methods (Static)
        
        function ShowPopularities(Points, PopularityVector, Border, ExtraRightBorder, MarkerType, MarkerSize, LegendBoxSize, LegendTextOffset, FontSize)
            
            RowSize = (max(Points(:,2))-min(Points(:,2)))/25; LegendBorder = RowSize/5;
            
            MinData = min(Points); MaxData = max(Points); RangeData = MaxData - MinData;
            L = MinData(1)-Border; B = MinData(2)-Border;
            W = RangeData(1)+2*Border; H = RangeData(2)+2*Border; W = W + ExtraRightBorder;
            R = L + W; T = B + H;
            LR = R - LegendBorder; LT = T - LegendBorder;
            LL = LR - LegendBoxSize(1); LB = LT - LegendBoxSize(2);
            LegendPosition = [LL, LT];
            
            
            
            PopularityVector = 10*PopularityVector;
            for i = 1:10
                BI_Ci = ceil(PopularityVector) == i;
                Color = ((10-i)/10)*[1, 1, 1];
                scatter(Points(BI_Ci, 1), Points(BI_Ci, 2), MarkerSize, Color,'filled', MarkerType);
                if (i<=6)
                    BorderColor = ((10-i-4)/10)*[1, 1, 1];
                    scatter(Points(BI_Ci, 1), Points(BI_Ci, 2), MarkerSize, BorderColor, MarkerType);
                end
                if i==1
                    hold on
                end
            end
            
            BI_Ci = ceil(PopularityVector) >= 10;
            scatter(Points(BI_Ci, 1), Points(BI_Ci, 2), MarkerSize, 'k','filled', MarkerType);
            
            rectangle('Position', [LL LB LegendBoxSize(1) LegendBoxSize(2)],'EdgeColor',0.75*[1 1 1],'FaceColor',1.00*[1 1 1]);
            
            BI_Ci = PopularityVector == 0;
            scatter(Points(BI_Ci, 1), Points(BI_Ci, 2), MarkerSize, 'k', MarkerType);
            Captions = {'\pi \approx 0','\pi \in (0, 0.1]','\pi \in (0.1, 0.2]','\pi \in (0.2, 0.3]','\pi \in (0.3, 0.4]', ...
                '\pi \in (0.4, 0.5]', '\pi \in (0.5, 0.6]','\pi \in (0.6, 0.7]', '\pi \in (0.7, 0.8]','\pi \in (0.8, 0.9]','\pi \in (0.9, \infty)'};
            for i = 0:10
                Color = ((10-i)/10)*[1, 1, 1];
                scatter(LegendPosition(1) + LegendTextOffset(1) - 3*LegendBorder, LegendPosition(2) + LegendTextOffset(2) - i * RowSize, MarkerSize*2, Color,'filled', MarkerType);
                if i==0
                    scatter(LegendPosition(1) + LegendTextOffset(1) - 3*LegendBorder, LegendPosition(2) + LegendTextOffset(2) - i * RowSize, MarkerSize*2, 'k', MarkerType);
                end
                if (i<=8)
                    BorderColor = ((10-i-2)/10)*[1, 1, 1];
                    scatter(LegendPosition(1) + LegendTextOffset(1) - 3*LegendBorder, LegendPosition(2) + LegendTextOffset(2) - i * RowSize, MarkerSize*2, BorderColor, MarkerType);
                end
                text(LegendPosition(1) + LegendTextOffset(1), LegendPosition(2) + LegendTextOffset(2) - i * RowSize, Captions{i+1} ,'FontName', 'Arial', 'FontSize', FontSize, 'FontWeight','normal',  'Color', 'k');
            end
            
            rectangle('Position', [L B W H])
            DataPresentation.HideAxis();
            axis equal
        end
        
        function ShowPopularitiesAsLabels(Points, PopularityVector)
            Points = normalize(Points,'range');
            RoundedPopularityVector = round(PopularityVector,2);
            DataPresentation.ScatterPlotAndLabels(Points, RoundedPopularityVector,[-0.014,0.001], 'o',750, 'k', 'w', 'k', 13);            
            DataPresentation.HideAxis();
        end
        
        function [PopularityVector, Outputs] = GetPopularityVectorWithDefaultWeightVector(DistanceMatrix, K, N_Iterations)
            if nargin < 2
                K = Popularity.GetMinimimValueOfKForWhichPopularityNSSDIsSufficientlySmall(DistanceMatrix);
            end
            if nargin < 3
                N_Iterations = Popularity.DefaultMaximumNumberOfIterations;
            end
            Kn = Popularity.DefaultKnFactor * K;
            N_Points = size(DistanceMatrix, 1);
            DistanceMatrix(1:N_Points+1:end) = Inf;
            [~, KnNNIndices] = mink(DistanceMatrix, Kn);
            if Popularity.DefaultSelfLoop
                WeightVector = Popularity.GetWeightVector(Popularity.DefaultWeightVectorComputationMethod, Kn+1, 2/(Kn+1+1));
                WeightVector = [WeightVector(end); WeightVector(1:end-1)];
                N_Points = size(KnNNIndices, 2);
                KnNNIndices = [1:N_Points;KnNNIndices];
            else
                WeightVector = Popularity.GetWeightVector(Popularity.DefaultWeightVectorComputationMethod, Kn, Popularity.DefaultWeightVectorComputationParameter);
            end
            [PopularityVector, O] = Popularity.GetPopularityVector(KnNNIndices, WeightVector, N_Iterations, Popularity.DefaultNSSDThresholdForNumberOfIterations);
            disp("O.N_Iterations")
            disp(O.N_Iterations)
            Outputs.K = K;
            Outputs.N_Iterations = N_Iterations;
            Outputs.WeightVector = WeightVector; 
            Outputs.KnNNIndices = KnNNIndices;
            Outputs.Kn = Kn;
        end

        
        function WeightVector = GetWeightVector(Method, k, Parameter, SelfLoop)%OK
            if nargin < 4
                SelfLoop = false;
            end
            if SelfLoop
                k = k+1; 
            end
            if strcmpi(Method, 'GeometricWithRatio')
                Ratio = Parameter;
                WeightVector = Popularity.GetWeightVector_GeometricWithRatio(k, Ratio);
            end
            if strcmpi(Method, 'GeometricWithMinValue')
                MinValue = Parameter;
                WeightVector = Popularity.GetWeightVector_GeometricWithMinValue(k, MinValue);
            end
            if SelfLoop
                WeightVector = [WeightVector(end); WeightVector(1:end-1)];
            end
        end
        
        function Ratio = GetRatio(k, t, Wt)%OK
            % Wi = a * r^(i-1)
            % a * (1-r^k)/(1-r) = 1    &    a * r^(t-1) = Wt =>
            % a = Wt / (r^(t-1));
            % Wt / (r^(t-1)) * (1-r^k)/(1-r) = 1
            % a =(1-Wk*(k+1)/2)/((k-1)/2); a=(2 - Wk*(k+1)) / (k-1);
            % Wt*(1-r^k) - r^(t-1)*(1-r) = 0
            L = 0; U = 1;
            ConvergenceThreshold = 0.000001;
            while (U-L)> ConvergenceThreshold
                M = (L+U)/2;
                Error = Wt*(1-M^k) - M^(t-1)*(1-M);
                if Error > 0
                    L = M;
                else
                    if Error < 0
                        U = M;
                    else
                        break
                    end
                end
            end
            Ratio = (L+U)/2;
        end
        
        function WeightVector = GetWeightVector_GeometricWithRatio(k, Ratio)%OK
            % a * (1-r^k)/(1-r) = 1 => a = (1-r) / (1-r^k)
            Scale = 20%evalin('base','ScaleValue');
            if Ratio <= 0
                Wk = 10.^(-1-(k/Scale));
                Ratio = Popularity.GetRatio(k, k, Wk);
            end
            if Ratio == 1
                WeightVector = ones(k,1)/k;
            else
                a = (1-Ratio) / (1-Ratio^k);
                WeightVector = a*Ratio.^(0:k-1)';
                WeightVector = WeightVector/sum(WeightVector);
            end            
        end
        
        function WeightVector = GetWeightVector_GeometricWithMinValue(k, MinValue)%OK
            % a * (1-r^k)/(1-r) = 1 => a = (1-r) / (1-r^k)
            if MinValue<=0
                MinValue = 10.^(-1-(k/10));                
            end
            Ratio = Popularity.GetRatio(k, k, MinValue);
            a = (1-Ratio) / (1-Ratio^k);
            WeightVector = a*Ratio.^(0:k-1)';
            WeightVector = WeightVector/sum(WeightVector);
        end
        
        
        function [ValueOfK, NSSD] = MinimimValueOfKForWhichNSSDIsSufficientlySmall(DistanceMatrix, N_Iterations, Threshold, MaxK)
            if nargin < 4
                MaxK = 100;
            end
            ValueOfK = 0;
            N_Points = size(DistanceMatrix, 1);
            while ~(5*MaxK<N_Points)
                MaxK = MaxK - 1;
            end
            
            N_Points = size(DistanceMatrix, 1);
            for K = 1:MaxK
                PopularityVector = Popularity.Compute1(DistanceMatrix, K, N_Iterations);
                if K==1
                    OldPopularityVector = PopularityVector;
                    NSSD(K) = inf;
                else
                    NSSD(K) = sum(abs(PopularityVector - OldPopularityVector).^2)/N_Points;
                    OldPopularityVector = PopularityVector;
                end
                if NSSD(K) <= Threshold
                    ValueOfK = K;
                    break;
                end
            end
            if ValueOfK == 0
                ValueOfK = MaxK;
            end
        end
        function ReverseKnNNRank = GetReverseKnNNRank(KnNNIndices)
            N_Points = size(KnNNIndices, 2);
            Kn = size(KnNNIndices, 1);
            RankMatrix = (Kn+1)*ones(N_Points,'uint16');
            PointsIndices = repmat(1:N_Points, Kn, 1);
            LinearIndices = sub2ind(size(RankMatrix), KnNNIndices(:), PointsIndices(:));
            RankMatrix(LinearIndices) = repmat((1:Kn)', 1, N_Points);
            LinearIndices = sub2ind(size(RankMatrix), PointsIndices(:), KnNNIndices(:));
            ReverseKnNNRank = reshape(RankMatrix(LinearIndices), Kn, N_Points);
        end
        
        function [PopularityVector, Outputs] = GetPopularityVector(KnNNIndices, WeightVector, ...
                MaximumNumberOfIterations, NSSDThreshold)%OK works for situations with self loops
            if nargin < 3
                MaximumNumberOfIterations = Popularity.DefaultMaximumNumberOfIterations;
            end            
            if nargin < 4
                NSSDThreshold = Popularity.DefaultNSSDThresholdForNumberOfIterations;
            end
            assert(size(KnNNIndices, 1)== numel(WeightVector),'Size error!')
            assert(iscolumn(WeightVector), 'WeightVector must be a column vector!')
            assert(NSSDThreshold > 0 || (0 <= MaximumNumberOfIterations && MaximumNumberOfIterations < inf))
            N_Points = size(KnNNIndices, 2);
            OldPopularityVector = ones(1, N_Points);
            N_Iterations = 0;
            Done = false;
            if MaximumNumberOfIterations == 0
                PopularityVector = OldPopularityVector;
                Done = true;
            end
            NSSDVector = [];
            if MaximumNumberOfIterations < 0
                MaximumNumberOfIterations = Popularity.DefaultUpperBoundForNumberOfIterations; 
            end
            while ~Done
                WeightMatrix = repmat(WeightVector, 1, N_Points).* OldPopularityVector;
                PopularityVector = zeros(1, N_Points);
                for i = 1:N_Points
                    PopularityVector(KnNNIndices(:,i)) = PopularityVector(KnNNIndices(:,i)) + WeightMatrix(:,i)';
                end
                N_Iterations = N_Iterations + 1;
                NSSDVector(N_Iterations) = sum((PopularityVector - OldPopularityVector).^2)/N_Points;
                OldPopularityVector = PopularityVector;
                Done = (N_Iterations >= MaximumNumberOfIterations && MaximumNumberOfIterations >=0) || NSSDVector(N_Iterations)<=NSSDThreshold;
            end
            Outputs.NSSDVector = NSSDVector;
            Outputs.N_Iterations = N_Iterations;
        end
        
        function [MinimimValueOfK, Outputs] = GetMinimimValueOfKForWhichPopularityNSSDIsSufficientlySmall...
                (DistanceMatrix, varargin) % OK
            IP = inputParser;
            addOptional(IP, 'WeightVectorComputationMethod', Popularity.DefaultWeightVectorComputationMethod);
            addOptional(IP, 'WeightVectorComputationParameter', Popularity.DefaultWeightVectorComputationParameter);
            addOptional(IP, 'MaximumNumberOfIterations', Popularity.DefaultMaximumNumberOfIterations);
            addOptional(IP, 'NSSDThresholdForNumberOfIterations', Popularity.DefaultNSSDThresholdForNumberOfIterations);
            addOptional(IP, 'SelfLoop', Popularity.DefaultSelfLoop); 
            addOptional(IP, 'MaxK', Popularity.DefaultMaxK);
            addOptional(IP, 'NSSDThresholdForK', Popularity.DefaultNSSDThresholdForK);
            addOptional(IP, 'KnFactor', Popularity.DefaultKnFactor);
            parse(IP, varargin{:});
            Args = IP.Results;
            WeightVectorComputationMethod = Args.WeightVectorComputationMethod;
            WeightVectorComputationParameter = Args.WeightVectorComputationParameter;
            MaximumNumberOfIterations = Args.MaximumNumberOfIterations; SelfLoop = Args.SelfLoop;
            NSSDThresholdForNumberOfIterations = Args.NSSDThresholdForNumberOfIterations;
            MaxK = Args.MaxK; NSSDThresholdForK = Args.NSSDThresholdForK; KnFactor = Args.KnFactor;
            
            N_Points = size(DistanceMatrix, 1);
            DistanceMatrix(1:N_Points+1:end) = Inf;            
            while ~(KnFactor*MaxK<N_Points), MaxK = MaxK - 1; end
            for K = 1:MaxK
                Kn = KnFactor*K;
                [~, KnNNIndices] = mink(DistanceMatrix, Kn);
                WeightVector = Popularity.GetWeightVector(WeightVectorComputationMethod, Kn, ...
                    WeightVectorComputationParameter, SelfLoop);
                if SelfLoop
                    KnNNIndices = [1:N_Points; KnNNIndices]; 
                end                
                PopularityVector = Popularity.GetPopularityVector(KnNNIndices, WeightVector, ...
                    MaximumNumberOfIterations, NSSDThresholdForNumberOfIterations);
                if K==1
                    OldPopularityVector = PopularityVector;
                    NSSDVector(K) = inf;
                else
                    NSSDVector(K) = sum((PopularityVector - OldPopularityVector).^2)/N_Points;
                    OldPopularityVector = PopularityVector;
                end
                if NSSDVector(K) <= NSSDThresholdForK
                    MinimimValueOfK = K;
                    return;
                end
            end
            MinimimValueOfK = MaxK;
            Outputs.PopularityVector = PopularityVector;
            Outputs.WeightVector = WeightVector;
            Outputs.NSSDVector = NSSDVector;            
        end
        
        function RankMatrix = GetRankMatrix(DistanceMatrix, K)
            N_Points = size(DistanceMatrix, 1);
            DistanceMatrix(1:N_Points+1:end) = Inf;
            % R(i, j) is the rank of i in the list of nearest neighbors of j
            if Popularity.DefaultSelfLoop
                assert(K<=N_Points);
                [~, KNNIndices] = mink(DistanceMatrix, K);
                KnNNIndices = [1:N_Points; KnNNIndices];
                RankMatrix = (K+1+1)*ones(N_Points);
                ColumnIndices = repmat(1:N_Points, K+1, 1);
                LinearIndices = sub2ind(size(RankMatrix), KNNIndices(:), ColumnIndices(:));
                RankMatrix(LinearIndices) = repmat((1:K+1)', 1, N_Points);
            else
                assert(K<N_Points);
                [~, KNNIndices] = mink(DistanceMatrix, K);
                RankMatrix = (K+1)*ones(N_Points);
                ColumnIndices = repmat(1:N_Points, K, 1);
                LinearIndices = sub2ind(size(RankMatrix), KNNIndices(:), ColumnIndices(:));
                RankMatrix(LinearIndices) = repmat((1:K)', 1, N_Points);
            end           
        end

        function CreditMatrix = GetCreditMatrix(DistanceMatrix, K)
            WeightVectorIsComputed = false;
            if nargin < 2 || K <= 0
                [K, Outputs] = Popularity.GetMinimimValueOfKForWhichPopularityNSSDIsSufficientlySmall(DistanceMatrix);
                WeightVector = Outputs.WeightVector;
                WeightVectorIsComputed = true;
            end           
            Kn = Popularity.DefaultKnFactor * K;
            if ~WeightVectorIsComputed                
                N_Points = size(DistanceMatrix, 1);
                DistanceMatrix(1:N_Points+1:end) = Inf;
                [~, KnNNIndices] = mink(DistanceMatrix, Kn);
                if Popularity.DefaultSelfLoop
                    WeightVector = Popularity.GetWeightVector(Popularity.DefaultWeightVectorComputationMethod, Kn+1, 2/(Kn+1+1));
                    WeightVector = [WeightVector(end); WeightVector(1:end-1)];
                    N_Points = size(KnNNIndices, 2);
                    KnNNIndices = [1:N_Points;KnNNIndices];
                else
                    WeightVector = Popularity.GetWeightVector(Popularity.DefaultWeightVectorComputationMethod, Kn, Popularity.DefaultWeightVectorComputationParameter);
                end
            end
            RankMatrix = Popularity.GetRankMatrix(DistanceMatrix, Kn);
            if Popularity.DefaultSelfLoop                
                CreditMatrix = WeightVector(RankMatrix+1);
            else
                WeightVector = [WeightVector; 0];
                CreditMatrix = WeightVector(RankMatrix);
            end
        end
    end
end