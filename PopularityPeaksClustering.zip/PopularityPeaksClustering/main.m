% Matlab source code for "Popularity Peaks Clustering (PPC) algorithm"
% Please cite [Hassan Motallebi and Najmeh Malakoutifar‎: An efficient clustering algorithm based on searching popularity peaks, Pattern Analysis and Applications, 2024]

% Please run "main.m" file

Samples = [12,-28;37,-27;20,18;31,-19;-15,-16;33,23;-4,26;-39,-11;41,-12;42,-9;17,28;14,-2;23,-6;-48,5;8,-19;28,35;-33,18;42,-27;2,-14;
    32,-10;19,-14;49,12;2,-2;39,-19;-18,-41;4,-46;-1,-15;-26,20;-15,-21;21,38;-9,-39;47,7;35,2;25,7;14,10;7,-17;-17,-45;-16,35;35,-12;
    19,6;-46,18;-29,24;24,-29;9,-36;13,29;-13,1;-23,9;-10,-14;-7,-19;1,-25;-4,32;-5,-9;-27,-39;25,42;26,24;-35,0;29,-9;-26,42;-26,-16;
    5,17;-2,-44;1,31;-24,-2;-9,-31;10,-10;17,-3;-47,-15;32,38;21,31;0,12;12,-21;-1,29;18,-42;1,5;10,-4;-11,16;13,38;0,43;-31,-28;
    -44,-15;-21,30;13,-26;-37,-21;-20,-4;37,-20;-4,21;3,-30;2,-41;-32,32;-14,-5;42,23;43,14;-36,-6;6,-33;29,-14;20,20;-32,-16;-35,6;
    45,3;-26,36;120,79;159,107;17,59;130,72;114,105;65,151;91,82;114,116;211,98;187,139;66,72;195,106;126,122;102,138;125,151;98,108;
    100,60;149,83;176,53;147,176;124,87;68,127;126,99;153,132;175,79;135,63;126,62;95,120;113,100;80,99;131,148;29,124;72,46;80,153;
    13,80;147,126;114,130;46,100;145,111;45,55;101,71;31,85;114,127;113,183;78,85;103,111;99,103;123,27;137,92;137,51];
Labels = [ones(100, 1);2*ones(50, 1)];

DistanceMatrix = squareform(pdist(Samples));
subplot(1,2,1)
scatter(Samples(:, 1), Samples(:, 2), 50, Labels);
title('ground-truth')
N_Clusters = 2;
%LabelPropagationMethod = "NearestHigherPopularityNeighbor"
LabelPropagationMethod = "HigherPopularityAndMaximumScore"
k = 10;
[ClusterIndices, OutputArgs] = PopularityPeaksClustering.PerfromClustering(DistanceMatrix, N_Clusters, LabelPropagationMethod, 'k', k);
subplot(1,2,2)
scatter(Samples(:, 1), Samples(:, 2), 50, ClusterIndices);
title('clustering result')
