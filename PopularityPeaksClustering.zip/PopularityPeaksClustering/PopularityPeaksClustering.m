classdef (ConstructOnLoad) PopularityPeaksClustering
    properties (Constant)
        DefaultCenterPointsIdentificationMethod = 'Classic';
        DefaultWeightVectorComputationMethod = 'GeometricWithMinValue';
        DefaultWeightVectorComputationParameter = 0.1;
        DefaultMaximumNumberOfIterations = -1;
        DefaultNSSDThresholdForNumberOfIterations = 0.001;
        DefaultMaxK = 100;
        DefaultNSSDThresholdForK = 0.001;
        DefaultK = 0;
        DefaultSelfLoop = false;
        DefaultKOffset = 5;
    end
    methods (Static)        
        function [PopularityVector, KnNNIndices, WeightVector] = GetPopularityVector(DistanceMatrix, varargin)
            IP = PopularityPeaksClustering.GetInputParserWithDefaultValues();
            parse(IP, varargin{:});
            Args = IP.Results;
            
            K = Args.K;
            
            if K == 0                
                MinimimValueOfK = Popularity.GetMinimimValueOfKForWhichPopularityNSSDIsSufficientlySmall...
                    (DistanceMatrix, varargin{:});
                K = MinimimValueOfK;
            end
            
            N_Points = size(DistanceMatrix, 1);
            DistanceMatrix(1:N_Points+1:end) = inf;
            Kn = K;
            while ~(Kn < N_Points), Kn = Kn - 1; end
            if (Kn < 1), Kn = 1; end
            
            assert(Kn > 0 && Kn<N_Points);
            
            [~, KnNNIndices] = mink(DistanceMatrix, Kn);
            WeightVector = Popularity.GetWeightVector(Args.WeightVectorComputationMethod, Kn, Args.WeightVectorComputationParameter, Args.SelfLoop);
            if Args.SelfLoop
                [PopularityVector, NSSDVector] = Popularity.GetPopularityVector([1:N_Points; KnNNIndices], WeightVector, Args.MaximumNumberOfIterations, Args.NSSDThresholdForK);
                WeightVector = WeightVector(2:end);
            else
                [PopularityVector, NSSDVector] = Popularity.GetPopularityVector(KnNNIndices, WeightVector, Args.MaximumNumberOfIterations, Args.NSSDThresholdForK);
            end            
        end
        
        function [DirectSuperiorVector, DistanceToDirectSuperiorVector] = GetDirectSuperiorVector...
                (Method, DistanceMatrix, PopularityVector, Args)
            if strcmp(Method, 'NearestHigherPopularityNeighbor')
                [DirectSuperiorVector, DistanceToDirectSuperiorVector] = PopularityPeaksClustering.GetDirectSuperiorVector_NearestHigherPopularityNeighbor...
                    (DistanceMatrix, PopularityVector);
            end
            if strcmp(Method, 'HigherPopularityAndMaximumScore')
                [DirectSuperiorVector, DistanceToDirectSuperiorVector] = PopularityPeaksClustering.GetDirectSuperiorVector_HigherPopularityAndMaximumScore...
                    (DistanceMatrix, PopularityVector, Args);
            end    
        end
        
        function [DirectSuperiorVector, DistanceToDirectSuperiorVector] = GetDirectSuperiorVector_NearestHigherPopularityNeighbor...
                (DistanceMatrix, PopularityVector)   
            if iscolumn(PopularityVector), PopularityVector = PopularityVector'; end
            BI_PointsWithMaximumPopularity = PopularityVector == max(PopularityVector);
            DistanceToDirectSuperiorForPointsWithMaximumPopularity = ...
                max(DistanceMatrix(BI_PointsWithMaximumPopularity, :), [], 2);
            
            [SortedPopularityVector, SortOrder] = sort(PopularityVector);            
            DistanceMatrix = DistanceMatrix(SortOrder, SortOrder);
            
            MaskMatrix = SortedPopularityVector' < SortedPopularityVector;
            DistanceMatrix(~MaskMatrix) = Inf;
            [DistanceToDirectSuperiorVector, DirectSuperiorVector] = min(DistanceMatrix, [], 2);  
            
            [~, ReverseSortOrder] = sort(SortOrder);
            DistanceToDirectSuperiorVector = DistanceToDirectSuperiorVector(ReverseSortOrder);
            DirectSuperiorVector = SortOrder(DirectSuperiorVector);
            DirectSuperiorVector = DirectSuperiorVector(ReverseSortOrder); 
            
            DistanceToDirectSuperiorVector(BI_PointsWithMaximumPopularity) = DistanceToDirectSuperiorForPointsWithMaximumPopularity;
            DirectSuperiorVector(BI_PointsWithMaximumPopularity) = nan;            
        end
            
        function [DirectSuperiorVector, DistanceToDirectSuperiorVector] = ...
                GetDirectSuperiorVector_HigherPopularityAndMaximumScore(DistanceMatrix, PopularityVector, Args)
            
            N_Points = size(DistanceMatrix, 1);
            BI_PointsWithMaximumPopularity = PopularityVector == max(PopularityVector);
            DistanceToDirectSuperiorVectorForPointsWithMaximumPopularity = ...
                max(DistanceMatrix(BI_PointsWithMaximumPopularity, :), [], 2);
            
            if iscolumn(PopularityVector), PopularityVector = PopularityVector'; end
            KnNNIndices = Args.KnNNIndices;
            WeightVector = Args.WeightVector;
            BIM = PopularityVector(KnNNIndices) > PopularityVector;
            ExtendedWeightVector = [WeightVector; 0]';
            ReverseKnNNRank = Popularity.GetReverseKnNNRank(KnNNIndices);
            KnNNSimilaritiesMatrix = ExtendedWeightVector(ReverseKnNNRank) .* BIM;
            KnNNScoreMatrix = KnNNSimilaritiesMatrix .* PopularityVector(ReverseKnNNRank); 
            [ScoreVector, IndexVector] = max(KnNNScoreMatrix, [], 1);
            BI_DirectSuperiorNotFound = ScoreVector == 0;
            
            LinearIndices = sub2ind(size(KnNNIndices), IndexVector, 1:N_Points);
            DirectSuperiorVector = KnNNIndices(LinearIndices);  
            LinearIndices = sub2ind(size(DistanceMatrix), 1:N_Points, DirectSuperiorVector);
            DistanceToDirectSuperiorVector = DistanceMatrix(LinearIndices);
            
            if nnz(BI_DirectSuperiorNotFound) > 0                
                [SortedPopularityVector, SortOrder] = sort(PopularityVector);
                DistanceMatrix = DistanceMatrix(SortOrder, SortOrder);
                BI_DirectSuperiorNotFound_Sorted = BI_DirectSuperiorNotFound(SortOrder);
                [~, ReverseSortOrder] = sort(SortOrder);
                
                MaskMatrix = SortedPopularityVector' < SortedPopularityVector;
                DistanceMatrix(~MaskMatrix) = Inf;
                DistanceMatrixForDanglingPoints = DistanceMatrix(BI_DirectSuperiorNotFound_Sorted,:);
                [DistanceToDirectSuperiorVectorForDanglingPoints, DirectSuperiorVectorForDanglingPoints] = ...
                    min(DistanceMatrixForDanglingPoints, [], 2);
                DirectSuperiorVectorForDanglingPoints = SortOrder(DirectSuperiorVectorForDanglingPoints);
                
                [~, D_] = sort(ReverseSortOrder(BI_DirectSuperiorNotFound));
                [~, PartialReverseSortOrder] = sort(D_);
                
                DistanceToDirectSuperiorVectorForDanglingPoints = DistanceToDirectSuperiorVectorForDanglingPoints(PartialReverseSortOrder);
                DirectSuperiorVectorForDanglingPoints = DirectSuperiorVectorForDanglingPoints(PartialReverseSortOrder);

                DistanceToDirectSuperiorVector(BI_DirectSuperiorNotFound) = DistanceToDirectSuperiorVectorForDanglingPoints;
                DirectSuperiorVector(BI_DirectSuperiorNotFound) = DirectSuperiorVectorForDanglingPoints;
            end
            
            DistanceToDirectSuperiorVector(BI_PointsWithMaximumPopularity) = DistanceToDirectSuperiorVectorForPointsWithMaximumPopularity;
            DirectSuperiorVector(BI_PointsWithMaximumPopularity) = nan;  
        end
        
        function CenterPointsIndices = GetCenterPoints(Method, N_CenterPoints, PopularityVector, DeltaVector, Args)
            if strcmp(Method, 'Classic')
                CenterPointsIndices = PopularityPeaksClustering.GetCenterPoints_Classic(N_CenterPoints, PopularityVector, DeltaVector);
            end              
        end
        
        function CenterPointsIndices = GetCenterPoints_Classic(N_CenterPoints, PopularityVector, DeltaVector)
            if ~iscolumn(PopularityVector), PopularityVector = PopularityVector'; end
            if ~iscolumn(DeltaVector), DeltaVector = DeltaVector'; end
            GammaVector = PopularityVector .* DeltaVector;
            [~, CenterPointsIndices] = maxk(GammaVector, N_CenterPoints);
         end
      
        function [ClusterIndices, IncidenceMatrix]  = AssignClusterIndicesToPoints(DirectSuperiorVector, PopularityVector, CenterPointsIndices)
            N_Points = numel(PopularityVector); N_Clusters = numel(CenterPointsIndices);
            ClusterIndices = zeros(N_Points, 1);
            ClusterIndices(CenterPointsIndices) = 1:N_Clusters;
            if nargout > 1, IncidenceMatrix = false(N_Points); end
            [~, SortOrder] = sort(PopularityVector);
            for Index = N_Points:-1:1
                DirectSubordinateIndex = SortOrder(Index);
                DirectSuperiorIndex = DirectSuperiorVector(DirectSubordinateIndex);
                if ~isnan(DirectSuperiorIndex)
                    ClusterIndices(DirectSubordinateIndex) = ClusterIndices(DirectSuperiorIndex);
                    
                    if nargout > 1
                        IncidenceMatrix(DirectSubordinateIndex, DirectSuperiorIndex) = true; 
                    end
                end
            end
        end
        
        function InputParser = GetInputParserWithDefaultValues()
            InputParser = inputParser;
            addOptional(InputParser, 'WeightVectorComputationMethod', PopularityPeaksClustering.DefaultWeightVectorComputationMethod);
            addOptional(InputParser, 'WeightVectorComputationParameter', PopularityPeaksClustering.DefaultWeightVectorComputationParameter);
            addOptional(InputParser, 'SelfLoop', PopularityPeaksClustering.DefaultSelfLoop);
            addOptional(InputParser, 'MaximumNumberOfIterations', PopularityPeaksClustering.DefaultMaximumNumberOfIterations);
            addOptional(InputParser, 'NSSDThresholdForNumberOfIterations', PopularityPeaksClustering.DefaultNSSDThresholdForNumberOfIterations);
            addOptional(InputParser, 'MaxK', PopularityPeaksClustering.DefaultMaxK);
            addOptional(InputParser, 'NSSDThresholdForK', PopularityPeaksClustering.DefaultNSSDThresholdForK);
            addOptional(InputParser, 'KOffset', PopularityPeaksClustering.DefaultKOffset);
            addOptional(InputParser, 'K', PopularityPeaksClustering.DefaultK);
        end
        
        function PlotResults(Points, CenterPointsIndices, IncidenceMatrix)                        
            gplot(IncidenceMatrix, Points, '-o')
            hold on
            scatter(Points(CenterPointsIndices, 1), Points(CenterPointsIndices, 2),250, 'r');
            hold off
            pause
        end
        
        function [ClusterIndices, OutputArgs] = PerfromClustering(DistanceMatrix, N_Clusters, LabelPropagationMethod, varargin)
            InputParser = PopularityPeaksClustering.GetInputParserWithDefaultValues();
            parse(InputParser, varargin{:});
            Args = InputParser.Results;
            
            Args.CenterPointsIdentificationMethod = PopularityPeaksClustering.DefaultCenterPointsIdentificationMethod;
            
            [PopularityVector, KnNNIndices, WeightVector] = PopularityPeaksClustering.GetPopularityVector(DistanceMatrix, varargin{:});
            OutputArgs.PopularityVector = PopularityVector;

            Agrs.WeightVector = WeightVector;
            Agrs.KnNNIndices = KnNNIndices;
            [DirectSuperiorVector, ScoreOrDeltaVector] = PopularityPeaksClustering.GetDirectSuperiorVector...
                (LabelPropagationMethod, DistanceMatrix, PopularityVector, Agrs);
                        
            ReverseKnNNRank = Popularity.GetReverseKnNNRank(KnNNIndices);
            
            CenterPointsIndices = PopularityPeaksClustering.GetCenterPoints...
                (Args.CenterPointsIdentificationMethod, N_Clusters, PopularityVector, ScoreOrDeltaVector);
            DirectSuperiorVector(CenterPointsIndices) = CenterPointsIndices;
            
            assert(nnz(isnan(DirectSuperiorVector))==0)
            if nargout > 1                
                [ClusterIndices, IncidenceMatrix] = PopularityPeaksClustering.AssignClusterIndicesToPoints(DirectSuperiorVector, PopularityVector, CenterPointsIndices);
                OutputArgs.IncidenceMatrix = IncidenceMatrix;
                OutputArgs.CenterPointsIndices = CenterPointsIndices;
                OutputArgs.PopularityVector = PopularityVector;
            else
                ClusterIndices = PopularityPeaksClustering.AssignClusterIndicesToPoints(DirectSuperiorVector, PopularityVector, CenterPointsIndices);
            end
            assert(nnz(ClusterIndices==0)==0)
        end 
    end
end